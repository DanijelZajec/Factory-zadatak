$('#slick1').slick({
		rows: 2,
		dots: false,
		arrows: true,
		infinite: true,
		variableWidth: true,
		speed: 400,
		slidesToShow: 4,
		slidesToScroll: 1,
		prevArrow:"<img class='a-left control-c prev slick-prev' src='arrow-gray-left.png'>",
		nextArrow:"<img class='a-right control-c next slick-next' src='arrow-blue-right.png'>"
});


